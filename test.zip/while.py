
i=0
while i<2:
    print(21)
    i+=1

print(1)
print(7)