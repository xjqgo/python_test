temp = int(input("请输入现在温度："))
if  0 < temp < 30:
    print("温度是适宜的")
else:
    print("温度是不适宜的")