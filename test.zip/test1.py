# 不过如此

print('122')

lx='''
lixi
7
--------------
'''
print(lx)
i=221
print(f'i:{i},type:{type(i)}')
i = '21'
i = '2'
print(f'i:{i},type:{i.__class__.__name__}')
print(i.__class__.__name__)