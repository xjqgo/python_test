import numpy as np


def print_board(board):
    print('  1 2 3 4 5 6 7 8 9')
    for i in range(9):
        print(i + 1, end=' ')
        for j in range(9):
            print(board[i][j], end=' ')
        print()


def check_win(board, player):
    # 检查行
    for i in range(9):
        for j in range(5):
            if np.all(board[i, j:j + 5] == player):
                return True
    # 检查列
    for j in range(9):
        for i in range(5):
            if np.all(board[i:i + 5, j] == player):
                return True
    # 检查正斜线
    for i in range(5):
        for j in range(5):
            if np.all(np.diagonal(board[i:i + 5, j:j + 5]) == player):
                return True
    # 检查反斜线
    for i in range(5):
        for j in range(4, 9):
            if np.all(np.diagonal(np.fliplr(board[i:i + 5, j - 4:j + 1])) == player):
                return True
    return False


def get_valid_moves(board):
    valid_moves = []
    for i in range(9):
        for j in range(9):
            if board[i][j] == '+':
                valid_moves.append((i, j))
    return valid_moves


def evaluate(board):
    scores = {'X': 0, 'O': 0}
    # 评估行
    for i in range(9):
        for j in range(9):
            row = board[i][j:j + 5]
            if np.all(row == 'X'):
                scores['X'] += 100
            elif np.all(row == 'O'):
                scores['O'] += 100
    # 评估列
    for j in range(9):
        for i in range(9):
            col = board[i:i + 5, j]
            if np.all(col == 'X'):
                scores['X'] += 100
            elif np.all(col == 'O'):
                scores['O'] += 100
    # 评估正斜线
    for i in range(5):
        for j in range(5):
            diag = np.diagonal(board[i:i + 5, j:j + 5])
            if np.all(diag == 'X'):
                scores['X'] += 100
            elif np.all(diag == 'O'):
                scores['O'] += 100
    # 评估反斜线
    for i in range(5):
        for j in range(4, 9):
            anti_diag = np.diagonal(np.fliplr(board[i:i + 5, j - 4:j + 1]))
            if np.all(anti_diag == 'X'):
                scores['X'] += 100
            elif np.all(anti_diag == 'O'):
                scores['O'] += 100
    return scores


def minimax(board, depth, alpha, beta, maximizingPlayer):
    valid_moves = get_valid_moves(board)
    if check_win(board, 'X'):
        return -10000
    elif check_win(board, 'O'):
        return 10000
    elif len(valid_moves) == 0:
        return 0
    if depth == 0:
        scores = evaluate(board)
        return scores['O'] - scores['X']
    if maximizingPlayer:
        maxEval = float('-inf')
        for move in valid_moves:
            i, j = move
            board[i][j] = 'O'
            eval = minimax(board, depth - 1, alpha, beta, False)
            board[i][j] = '+'
            maxEval = max(maxEval, eval)
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return maxEval
    else:
        minEval = float('inf')
        for move in valid_moves:
            i, j = move
            board[i][j] = 'X'
            eval = minimax(board, depth - 1, alpha, beta, True)
            board[i][j] = '+'
            minEval = min(minEval, eval)
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return minEval


def computer_move(board):
    best_score = float('-inf')
    best_move = None
    valid_moves = get_valid_moves(board)
    for move in valid_moves:
        i, j = move
        board[i][j] = 'O'
        score = minimax(board, 3, float('-inf'), float('inf'), False)
        board[i][j] = '+'
        if score > best_score:
            best_score = score
            best_move = move
    return best_move


def main():
    board = np.array([['+' for _ in range(9)] for _ in range(9)])
    while True:
        print_board(board)
        move = input("你是黑子，请你输入行列来落子，例如:18 表示1行8列\n")
        if len(move)!= 2 or not move[0].isdigit() or not move[1].isdigit():
            print("输入格式错误，请重新输入！")
            continue
        row, col = int(move[0]) - 1, int(move[1]) - 1
        if board[row][col]!= '+':
            print("该位置已有棋子，请重新选择！")
            continue
        board[row][col] = 'X'
        if check_win(board, 'X'):
            print_board(board)
            print("黑子获胜！")
            break
        # 电脑使用 minimax 算法落子（白子）
        white_move = computer_move(board)
        row, col = white_move
        board[row][col] = 'O'
        if check_win(board, 'O'):
            print_board(board)
            print("白子获胜！")
            break


if __name__ == "__main__":
    main()